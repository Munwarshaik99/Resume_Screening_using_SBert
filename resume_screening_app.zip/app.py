import streamlit as st

st.title("Resume Screening App")
st.write("Upload Job Description and Resumes to get matching scores.")
